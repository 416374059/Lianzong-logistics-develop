# Advanced techniques

This section describes advanced scrolling techniques.  
When you've done this topic, you could be be an expert of handling scrolls!  
I'd appreciate it if you could suggest new patterns or improvements of the library.

1. [Sliding up pattern](../../docs/advanced/sliding-up.md)
1. [ViewPager pattern](../../docs/advanced/viewpager.md)

[Next: Sliding up pattern &raquo;](../../docs/advanced/sliding-up.md)
