# ViewPager pattern

This topic describes how to integrate scrollable views with ViewPager,
which are implemented in the following examples.

* ViewPagerTab2Activity
* ViewPagerTabActivity
* ViewPagerTabFragmentActivity
* ViewPagerTabListViewActivity
* ViewPagerTabScrollViewActivity

---

Coming soon...
