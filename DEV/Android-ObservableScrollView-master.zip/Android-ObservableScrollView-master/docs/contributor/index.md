# For contributors

This section explains some operations for managing the project.

1. [CI](../../docs/contributor/ci.md)
1. [Update website](../../docs/contributor/update-website.md)
1. [Release](../../docs/contributor/release.md)

